import {startDialogue, makeChoice} from './dialogue.js';
import {phases, currentPhase} from './phases.js';

window.makeChoice = makeChoice;

startDialogue(phases[currentPhase].id);
