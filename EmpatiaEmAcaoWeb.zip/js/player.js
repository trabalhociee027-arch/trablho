export const player = {
  name: "Jogadora",
  empatia: 0,
  points: 0
};
